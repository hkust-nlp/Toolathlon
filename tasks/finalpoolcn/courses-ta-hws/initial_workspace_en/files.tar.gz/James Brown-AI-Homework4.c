#include <stdio.h>
#include <stdlib.h>

// Artificial Intelligence Assignment 4
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Artificial Intelligence HW4!\n");
    return 0;
}
