#include <stdio.h>
#include <stdlib.h>

// Computer Networks Assignment 5
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Computer Networks HW5!\n");
    return 0;
}
