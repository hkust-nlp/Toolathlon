#!/usr/bin/env python3
# Operating Systems Assignment 5
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Operating Systems HW5!")

if __name__ == "__main__":
    main()
