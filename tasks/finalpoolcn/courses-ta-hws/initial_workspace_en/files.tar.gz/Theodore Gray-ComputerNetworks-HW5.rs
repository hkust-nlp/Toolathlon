// Computer Networks Assignment 5
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Computer Networks HW5!");
}
