// Algorithm Design Assignment 2
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Algorithm Design HW2!");
}
