#!/usr/bin/env python3
# Artificial Intelligence Assignment 2
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Artificial Intelligence HW2!")

if __name__ == "__main__":
    main()
