#include <stdio.h>
#include <stdlib.h>

// Artificial Intelligence Assignment 2
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Artificial Intelligence HW2!\n");
    return 0;
}
