#!/usr/bin/env python3
# Database Principles Assignment 5
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Database Principles HW5!")

if __name__ == "__main__":
    main()
