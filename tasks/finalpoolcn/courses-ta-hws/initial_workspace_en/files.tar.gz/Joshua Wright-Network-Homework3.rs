// Computer Networks Assignment 3
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Computer Networks HW3!");
}
