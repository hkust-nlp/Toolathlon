// Data Structures Assignment 5
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Data Structures HW5!");
}
