#!/usr/bin/env python3
# Operating Systems Assignment 1
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Operating Systems HW1!")

if __name__ == "__main__":
    main()
