#include <stdio.h>
#include <stdlib.h>

// Software Engineering Assignment 4
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Software Engineering HW4!\n");
    return 0;
}
