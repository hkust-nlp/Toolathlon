// Compiler Principles Assignment 1
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Compiler Principles HW1!");
}
