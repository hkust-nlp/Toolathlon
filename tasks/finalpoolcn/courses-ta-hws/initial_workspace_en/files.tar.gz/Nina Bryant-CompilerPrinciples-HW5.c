#include <stdio.h>
#include <stdlib.h>

// Compiler Principles Assignment 5
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Compiler Principles HW5!\n");
    return 0;
}
