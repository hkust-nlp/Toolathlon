// Operating Systems Assignment 5
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Operating Systems HW5!");
}
