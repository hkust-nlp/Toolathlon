#include <stdio.h>
#include <stdlib.h>

// Data Structures Assignment 1
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Data Structures HW1!\n");
    return 0;
}
