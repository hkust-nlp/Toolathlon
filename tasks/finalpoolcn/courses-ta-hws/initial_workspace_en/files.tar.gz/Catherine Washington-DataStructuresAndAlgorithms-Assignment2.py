#!/usr/bin/env python3
# Data Structures Assignment 2
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Data Structures HW2!")

if __name__ == "__main__":
    main()
