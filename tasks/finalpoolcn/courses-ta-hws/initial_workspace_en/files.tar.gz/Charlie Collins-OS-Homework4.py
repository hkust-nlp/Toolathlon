#!/usr/bin/env python3
# Operating Systems Assignment 4
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Operating Systems HW4!")

if __name__ == "__main__":
    main()
