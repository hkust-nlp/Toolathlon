// Algorithm Design Assignment 5
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Algorithm Design HW5!");
}
