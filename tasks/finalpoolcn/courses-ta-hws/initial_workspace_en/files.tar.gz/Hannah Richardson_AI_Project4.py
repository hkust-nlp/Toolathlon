#!/usr/bin/env python3
# Artificial Intelligence Assignment 4
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Artificial Intelligence HW4!")

if __name__ == "__main__":
    main()
