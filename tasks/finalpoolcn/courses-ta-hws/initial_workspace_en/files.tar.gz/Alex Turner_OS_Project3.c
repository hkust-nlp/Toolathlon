#include <stdio.h>
#include <stdlib.h>

// Operating Systems Assignment 3
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Operating Systems HW3!\n");
    return 0;
}
