// Data Structures Assignment 1
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Data Structures HW1!");
}
