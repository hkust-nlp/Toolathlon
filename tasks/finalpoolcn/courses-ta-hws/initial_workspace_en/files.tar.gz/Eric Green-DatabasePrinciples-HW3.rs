// Database Principles Assignment 3
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Database Principles HW3!");
}
