// Software Engineering Assignment 3
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Software Engineering HW3!");
}
