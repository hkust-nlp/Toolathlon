// Operating Systems Assignment 3
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Operating Systems HW3!");
}
