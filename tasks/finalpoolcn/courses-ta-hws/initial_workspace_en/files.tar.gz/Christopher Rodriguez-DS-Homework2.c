#include <stdio.h>
#include <stdlib.h>

// Data Structures Assignment 2
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Data Structures HW2!\n");
    return 0;
}
