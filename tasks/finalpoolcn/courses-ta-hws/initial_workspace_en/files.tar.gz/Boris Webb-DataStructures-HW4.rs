// Data Structures Assignment 4
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Data Structures HW4!");
}
