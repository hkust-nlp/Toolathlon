#include <stdio.h>
#include <stdlib.h>

// Algorithm Design Assignment 3
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Algorithm Design HW3!\n");
    return 0;
}
