// Artificial Intelligence Assignment 2
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Artificial Intelligence HW2!");
}
