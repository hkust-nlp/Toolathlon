// Operating Systems Assignment 1
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Operating Systems HW1!");
}
