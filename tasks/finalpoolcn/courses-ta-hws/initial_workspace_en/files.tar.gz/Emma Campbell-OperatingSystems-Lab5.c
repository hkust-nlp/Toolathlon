#include <stdio.h>
#include <stdlib.h>

// Operating Systems Assignment 5
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Operating Systems HW5!\n");
    return 0;
}
