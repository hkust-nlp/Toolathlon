#include <stdio.h>
#include <stdlib.h>

// Algorithm Design Assignment 1
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Algorithm Design HW1!\n");
    return 0;
}
