// Software Engineering Assignment 5
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Software Engineering HW5!");
}
