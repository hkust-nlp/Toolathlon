// Database Principles Assignment 1
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Database Principles HW1!");
}
