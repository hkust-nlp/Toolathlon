// Data Structures Assignment 2
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Data Structures HW2!");
}
