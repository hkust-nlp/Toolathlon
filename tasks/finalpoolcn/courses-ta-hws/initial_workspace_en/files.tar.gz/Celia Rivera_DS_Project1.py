#!/usr/bin/env python3
# Data Structures Assignment 1
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Data Structures HW1!")

if __name__ == "__main__":
    main()
