#include <stdio.h>
#include <stdlib.h>

// Compiler Principles Assignment 4
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Compiler Principles HW4!\n");
    return 0;
}
