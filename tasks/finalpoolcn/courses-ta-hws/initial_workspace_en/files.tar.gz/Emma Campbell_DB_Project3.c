#include <stdio.h>
#include <stdlib.h>

// Database Principles Assignment 3
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Database Principles HW3!\n");
    return 0;
}
