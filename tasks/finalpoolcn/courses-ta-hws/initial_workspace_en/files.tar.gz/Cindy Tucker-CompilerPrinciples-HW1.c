#include <stdio.h>
#include <stdlib.h>

// Compiler Principles Assignment 1
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Compiler Principles HW1!\n");
    return 0;
}
