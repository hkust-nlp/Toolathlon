// Artificial Intelligence Assignment 3
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Artificial Intelligence HW3!");
}
