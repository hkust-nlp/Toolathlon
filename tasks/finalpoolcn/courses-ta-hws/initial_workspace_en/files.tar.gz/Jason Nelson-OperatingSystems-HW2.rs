// Operating Systems Assignment 2
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Operating Systems HW2!");
}
