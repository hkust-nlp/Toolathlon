// Operating Systems Assignment 4
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Operating Systems HW4!");
}
