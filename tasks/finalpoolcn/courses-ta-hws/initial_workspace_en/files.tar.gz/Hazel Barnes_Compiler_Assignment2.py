#!/usr/bin/env python3
# Compiler Principles Assignment 2
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Compiler Principles HW2!")

if __name__ == "__main__":
    main()
