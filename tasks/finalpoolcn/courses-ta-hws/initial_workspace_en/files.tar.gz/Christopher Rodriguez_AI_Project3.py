#!/usr/bin/env python3
# Artificial Intelligence Assignment 3
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Artificial Intelligence HW3!")

if __name__ == "__main__":
    main()
