#!/usr/bin/env python3
# Software Engineering Assignment 5
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Software Engineering HW5!")

if __name__ == "__main__":
    main()
