// Algorithm Design Assignment 3
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Algorithm Design HW3!");
}
