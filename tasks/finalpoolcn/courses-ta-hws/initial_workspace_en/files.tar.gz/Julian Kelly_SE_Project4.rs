// Software Engineering Assignment 4
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Software Engineering HW4!");
}
