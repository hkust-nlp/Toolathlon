#!/usr/bin/env python3
# Operating Systems Assignment 3
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Operating Systems HW3!")

if __name__ == "__main__":
    main()
