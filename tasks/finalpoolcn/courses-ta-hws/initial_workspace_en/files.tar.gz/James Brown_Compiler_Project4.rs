// Compiler Principles Assignment 4
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Compiler Principles HW4!");
}
