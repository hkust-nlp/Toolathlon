// Data Structures Assignment 3
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Data Structures HW3!");
}
