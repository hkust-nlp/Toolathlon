#include <stdio.h>
#include <stdlib.h>

// Artificial Intelligence Assignment 5
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Artificial Intelligence HW5!\n");
    return 0;
}
