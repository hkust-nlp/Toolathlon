// Compiler Principles Assignment 5
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Compiler Principles HW5!");
}
