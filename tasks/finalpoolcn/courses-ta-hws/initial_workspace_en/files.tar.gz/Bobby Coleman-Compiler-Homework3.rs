// Compiler Principles Assignment 3
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Compiler Principles HW3!");
}
