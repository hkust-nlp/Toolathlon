#include <stdio.h>
#include <stdlib.h>

// Artificial Intelligence Assignment 3
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Artificial Intelligence HW3!\n");
    return 0;
}
