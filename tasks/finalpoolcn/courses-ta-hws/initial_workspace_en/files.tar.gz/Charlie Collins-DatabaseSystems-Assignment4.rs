// Database Principles Assignment 4
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Database Principles HW4!");
}
