// Computer Networks Assignment 2
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Computer Networks HW2!");
}
