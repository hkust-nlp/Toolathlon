#include <stdio.h>
#include <stdlib.h>

// Computer Networks Assignment 1
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Computer Networks HW1!\n");
    return 0;
}
