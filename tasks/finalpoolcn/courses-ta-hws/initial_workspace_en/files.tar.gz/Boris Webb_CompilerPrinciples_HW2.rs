// Compiler Principles Assignment 2
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Compiler Principles HW2!");
}
