// Artificial Intelligence Assignment 4
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Artificial Intelligence HW4!");
}
