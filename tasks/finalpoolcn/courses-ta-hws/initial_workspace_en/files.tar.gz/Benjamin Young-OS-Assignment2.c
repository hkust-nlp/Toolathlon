#include <stdio.h>
#include <stdlib.h>

// Operating Systems Assignment 2
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Operating Systems HW2!\n");
    return 0;
}
