#include <stdio.h>
#include <stdlib.h>

// Data Structures Assignment 3
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Data Structures HW3!\n");
    return 0;
}
