#include <stdio.h>
#include <stdlib.h>

// Compiler Principles Assignment 3
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Compiler Principles HW3!\n");
    return 0;
}
