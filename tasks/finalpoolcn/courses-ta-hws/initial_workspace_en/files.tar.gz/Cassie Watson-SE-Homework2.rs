// Software Engineering Assignment 2
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Software Engineering HW2!");
}
