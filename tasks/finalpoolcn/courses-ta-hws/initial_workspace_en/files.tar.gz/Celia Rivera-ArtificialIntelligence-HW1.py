#!/usr/bin/env python3
# Artificial Intelligence Assignment 1
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Artificial Intelligence HW1!")

if __name__ == "__main__":
    main()
