// Computer Networks Assignment 4
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Computer Networks HW4!");
}
