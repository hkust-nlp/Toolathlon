#!/usr/bin/env python3
# Database Principles Assignment 4
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Database Principles HW4!")

if __name__ == "__main__":
    main()
