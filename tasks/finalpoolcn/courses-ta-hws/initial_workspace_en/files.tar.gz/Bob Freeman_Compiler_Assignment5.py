#!/usr/bin/env python3
# Compiler Principles Assignment 5
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Compiler Principles HW5!")

if __name__ == "__main__":
    main()
