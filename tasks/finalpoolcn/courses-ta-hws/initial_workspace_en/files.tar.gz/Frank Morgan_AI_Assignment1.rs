// Artificial Intelligence Assignment 1
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Artificial Intelligence HW1!");
}
