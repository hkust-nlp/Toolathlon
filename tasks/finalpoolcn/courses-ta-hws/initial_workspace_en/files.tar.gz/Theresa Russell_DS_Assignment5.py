#!/usr/bin/env python3
# Data Structures Assignment 5
# Algorithm and data structure implementation in Python

def main():
    print("Hello, Data Structures HW5!")

if __name__ == "__main__":
    main()
