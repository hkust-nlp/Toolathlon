#include <stdio.h>
#include <stdlib.h>

// Algorithm Design Assignment 2
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Algorithm Design HW2!\n");
    return 0;
}
