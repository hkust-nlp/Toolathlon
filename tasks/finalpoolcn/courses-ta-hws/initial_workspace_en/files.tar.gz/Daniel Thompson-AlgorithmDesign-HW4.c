#include <stdio.h>
#include <stdlib.h>

// Algorithm Design Assignment 4
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Algorithm Design HW4!\n");
    return 0;
}
