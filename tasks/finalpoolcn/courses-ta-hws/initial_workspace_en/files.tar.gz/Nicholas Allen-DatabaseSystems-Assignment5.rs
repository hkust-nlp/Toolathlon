// Database Principles Assignment 5
// Systems programming implementation using Rust

fn main() {
    println!("Hello, Database Principles HW5!");
}
