#include <stdio.h>
#include <stdlib.h>

// Artificial Intelligence Assignment 1
// Implementation of basic system calls and memory management

int main() {
    printf("Hello, Artificial Intelligence HW1!\n");
    return 0;
}
