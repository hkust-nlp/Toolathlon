#include <stdio.h>
#include <stdlib.h>

// 人工智能 第1次作业
// 实现基本的系统调用和内存管理

int main() {
    printf("Hello, 人工智能 HW1!\n");
    return 0;
}
