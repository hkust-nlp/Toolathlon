// 数据结构 第2次作业
// 使用Rust实现系统级编程

fn main() {
    println!("Hello, 数据结构 HW2!");
}
