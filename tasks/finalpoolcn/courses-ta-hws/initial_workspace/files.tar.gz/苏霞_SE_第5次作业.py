#!/usr/bin/env python3
# 软件工程 第5次作业
# Python实现算法和数据结构

def main():
    print("Hello, 软件工程 HW5!")

if __name__ == "__main__":
    main()
