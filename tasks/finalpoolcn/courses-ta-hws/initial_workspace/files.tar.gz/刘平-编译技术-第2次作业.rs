// 编译原理 第2次作业
// 使用Rust实现系统级编程

fn main() {
    println!("Hello, 编译原理 HW2!");
}
