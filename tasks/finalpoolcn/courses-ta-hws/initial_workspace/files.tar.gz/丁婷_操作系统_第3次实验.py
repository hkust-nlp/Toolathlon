#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
计算机系统基础 - 第3次作业
学生姓名: 丁婷
学号: 2021302034
作业主题: 网络爬虫
"""

def main():
    print(f"学生: 丁婷")
    print(f"学号: 2021302034")
    print(f"作业主题: 网络爬虫")
    
    # TODO: 实现网络爬虫相关功能
    pass

if __name__ == "__main__":
    main()
