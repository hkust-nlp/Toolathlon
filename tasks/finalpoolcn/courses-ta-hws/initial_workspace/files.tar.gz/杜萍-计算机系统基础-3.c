/*
 * 计算机系统基础 - 第3次作业
 * 学生姓名: 杜萍
 * 学号: 2021302040
 * 作业主题: 调度算法
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    printf("学生: 杜萍\n");
    printf("学号: 2021302040\n");
    printf("作业主题: 调度算法\n");
    
    // TODO: 实现调度算法相关功能
    
    return 0;
}
