#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
计算机系统基础 - 第3次作业
学生姓名: 徐燕
学号: 2021302050
作业主题: 自然语言处理
"""

def main():
    print(f"学生: 徐燕")
    print(f"学号: 2021302050")
    print(f"作业主题: 自然语言处理")
    
    # TODO: 实现自然语言处理相关功能
    pass

if __name__ == "__main__":
    main()
