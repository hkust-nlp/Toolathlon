#include <stdio.h>
#include <stdlib.h>

// 数据结构 第5次作业
// 实现基本的系统调用和内存管理

int main() {
    printf("Hello, 数据结构 HW5!\n");
    return 0;
}
