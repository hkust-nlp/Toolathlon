#!/usr/bin/env python3
# 操作系统基础 第1次作业
# Python实现算法和数据结构

def main():
    print("Hello, 操作系统基础 HW1!")

if __name__ == "__main__":
    main()
