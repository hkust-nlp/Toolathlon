#include <stdio.h>
#include <stdlib.h>

// 数据库原理 第2次作业
// 实现基本的系统调用和内存管理

int main() {
    printf("Hello, 数据库原理 HW2!\n");
    return 0;
}
