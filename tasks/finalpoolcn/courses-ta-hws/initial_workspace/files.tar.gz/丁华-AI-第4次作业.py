#!/usr/bin/env python3
# 人工智能 第4次作业
# Python实现算法和数据结构

def main():
    print("Hello, 人工智能 HW4!")

if __name__ == "__main__":
    main()
