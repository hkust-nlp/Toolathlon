#!/usr/bin/env python3
# 数据结构 第5次作业
# Python实现算法和数据结构

def main():
    print("Hello, 数据结构 HW5!")

if __name__ == "__main__":
    main()
