#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
计算机系统基础 - 第3次作业
学生姓名: 萧健
学号: 2021302090
作业主题: 系统监控
"""

def main():
    print(f"学生: 萧健")
    print(f"学号: 2021302090")
    print(f"作业主题: 系统监控")
    
    # TODO: 实现系统监控相关功能
    pass

if __name__ == "__main__":
    main()
