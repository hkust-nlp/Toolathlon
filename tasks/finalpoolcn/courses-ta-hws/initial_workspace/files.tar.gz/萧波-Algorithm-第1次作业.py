#!/usr/bin/env python3
# 算法设计 第1次作业
# Python实现算法和数据结构

def main():
    print("Hello, 算法设计 HW1!")

if __name__ == "__main__":
    main()
