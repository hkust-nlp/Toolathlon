/*
 * 计算机系统基础 - 第3次作业
 * 学生姓名: 何宁
 * 学号: 2021302080
 * 作业主题: 信号处理
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    printf("学生: 何宁\n");
    printf("学号: 2021302080\n");
    printf("作业主题: 信号处理\n");
    
    // TODO: 实现信号处理相关功能
    
    return 0;
}
