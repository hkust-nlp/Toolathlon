/*
 * 计算机系统基础 - 第3次作业
 * 学生姓名: 周磊
 * 学号: 2021302044
 * 作业主题: 线程同步
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    printf("学生: 周磊\n");
    printf("学号: 2021302044\n");
    printf("作业主题: 线程同步\n");
    
    // TODO: 实现线程同步相关功能
    
    return 0;
}
