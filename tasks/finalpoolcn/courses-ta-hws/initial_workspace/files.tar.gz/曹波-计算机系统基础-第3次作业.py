#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
计算机系统基础 - 第3次作业
学生姓名: 曹波
学号: 2021302099
作业主题: 机器学习
"""

def main():
    print(f"学生: 曹波")
    print(f"学号: 2021302099")
    print(f"作业主题: 机器学习")
    
    # TODO: 实现机器学习相关功能
    pass

if __name__ == "__main__":
    main()
