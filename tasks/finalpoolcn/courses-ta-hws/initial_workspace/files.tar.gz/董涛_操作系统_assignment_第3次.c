/*
 * 计算机系统基础 - 第3次作业
 * 学生姓名: 董涛
 * 学号: 2021302054
 * 作业主题: 虚拟内存
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    printf("学生: 董涛\n");
    printf("学号: 2021302054\n");
    printf("作业主题: 虚拟内存\n");
    
    // TODO: 实现虚拟内存相关功能
    
    return 0;
}
