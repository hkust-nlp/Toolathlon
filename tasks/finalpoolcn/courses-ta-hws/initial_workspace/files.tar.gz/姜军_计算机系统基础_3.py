#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
计算机系统基础 - 第3次作业
学生姓名: 姜军
学号: 2021302025
作业主题: 数据分析
"""

def main():
    print(f"学生: 姜军")
    print(f"学号: 2021302025")
    print(f"作业主题: 数据分析")
    
    # TODO: 实现数据分析相关功能
    pass

if __name__ == "__main__":
    main()
