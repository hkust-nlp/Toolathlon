#include <stdio.h>
#include <stdlib.h>

// 算法设计 第4次作业
// 实现基本的系统调用和内存管理

int main() {
    printf("Hello, 算法设计 HW4!\n");
    return 0;
}
