/*
 * 计算机系统基础 - 第3次作业
 * 学生姓名: 江丽
 * 学号: 2021302076
 * 作业主题: 线程同步
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    printf("学生: 江丽\n");
    printf("学号: 2021302076\n");
    printf("作业主题: 线程同步\n");
    
    // TODO: 实现线程同步相关功能
    
    return 0;
}
