#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
计算机系统基础 - 第3次作业
学生姓名: 方晨
学号: 2021302075
作业主题: Web开发
"""

def main():
    print(f"学生: 方晨")
    print(f"学号: 2021302075")
    print(f"作业主题: Web开发")
    
    # TODO: 实现Web开发相关功能
    pass

if __name__ == "__main__":
    main()
