/*
 * 计算机系统基础 - 第3次作业
 * 学生姓名: 王敏
 * 学号: 2021302029
 * 作业主题: 文件系统
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    printf("学生: 王敏\n");
    printf("学号: 2021302029\n");
    printf("作业主题: 文件系统\n");
    
    // TODO: 实现文件系统相关功能
    
    return 0;
}
