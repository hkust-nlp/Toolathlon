#!/usr/bin/env python3
# 数据库原理 第4次作业
# Python实现算法和数据结构

def main():
    print("Hello, 数据库原理 HW4!")

if __name__ == "__main__":
    main()
