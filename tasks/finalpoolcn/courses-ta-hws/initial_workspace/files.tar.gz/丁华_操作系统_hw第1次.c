#include <stdio.h>
#include <stdlib.h>

// 操作系统基础 第1次作业
// 实现基本的系统调用和内存管理

int main() {
    printf("Hello, 操作系统基础 HW1!\n");
    return 0;
}
