#include <stdio.h>
#include <stdlib.h>

// 数据结构 第1次作业
// 实现基本的系统调用和内存管理

int main() {
    printf("Hello, 数据结构 HW1!\n");
    return 0;
}
