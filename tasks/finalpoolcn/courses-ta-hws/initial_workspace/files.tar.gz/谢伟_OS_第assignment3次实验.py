#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
计算机系统基础 - 第3次作业
学生姓名: 谢伟
学号: 2021302038
作业主题: 数据库操作
"""

def main():
    print(f"学生: 谢伟")
    print(f"学号: 2021302038")
    print(f"作业主题: 数据库操作")
    
    # TODO: 实现数据库操作相关功能
    pass

if __name__ == "__main__":
    main()
