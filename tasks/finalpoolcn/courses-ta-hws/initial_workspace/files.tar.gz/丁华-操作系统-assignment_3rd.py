#!/usr/bin/env python3
# 操作系统基础 第3次作业
# Python实现算法和数据结构

def main():
    print("Hello, 操作系统基础 HW3!")

if __name__ == "__main__":
    main()
