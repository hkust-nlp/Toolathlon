// 软件工程 第1次作业
// 使用Rust实现系统级编程

fn main() {
    println!("Hello, 软件工程 HW1!");
}
