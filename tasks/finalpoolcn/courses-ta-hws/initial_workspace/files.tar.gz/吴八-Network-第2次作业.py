#!/usr/bin/env python3
# 计算机网络 第2次作业
# Python实现算法和数据结构

def main():
    print("Hello, 计算机网络 HW2!")

if __name__ == "__main__":
    main()
