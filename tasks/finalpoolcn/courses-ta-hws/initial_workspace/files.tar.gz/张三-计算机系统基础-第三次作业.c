/*
 * 操作系统第三次作业 - 进程管理
 * 学生：张三
 * 学号：2021302001
 * 学院：计算机科学技术学院
 * 文件ID：HW3_张三_OS
 */

#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("作业提交者：张三\n");
    printf("学号：2021302001\n");
    printf("作业内容：操作系统第三次作业 - 进程管理\n");
    return 0;
}
