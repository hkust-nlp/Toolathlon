// 数据库原理 第5次作业
// 使用Rust实现系统级编程

fn main() {
    println!("Hello, 数据库原理 HW5!");
}
