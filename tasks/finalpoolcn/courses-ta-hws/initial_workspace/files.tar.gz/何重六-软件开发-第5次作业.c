#include <stdio.h>
#include <stdlib.h>

// 软件工程 第5次作业
// 实现基本的系统调用和内存管理

int main() {
    printf("Hello, 软件工程 HW5!\n");
    return 0;
}
