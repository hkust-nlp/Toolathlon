#!/usr/bin/env python3
# 编译原理 第1次作业
# Python实现算法和数据结构

def main():
    print("Hello, 编译原理 HW1!")

if __name__ == "__main__":
    main()
