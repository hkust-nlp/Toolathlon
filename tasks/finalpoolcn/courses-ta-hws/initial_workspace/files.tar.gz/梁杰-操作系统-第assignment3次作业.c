/*
 * 计算机系统基础 - 第3次作业
 * 学生姓名: 梁杰
 * 学号: 2021302070
 * 作业主题: 死锁检测
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    printf("学生: 梁杰\n");
    printf("学号: 2021302070\n");
    printf("作业主题: 死锁检测\n");
    
    // TODO: 实现死锁检测相关功能
    
    return 0;
}
