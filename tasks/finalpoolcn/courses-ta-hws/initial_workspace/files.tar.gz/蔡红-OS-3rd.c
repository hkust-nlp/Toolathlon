/*
 * 计算机系统基础 - 第3次作业
 * 学生姓名: 蔡红
 * 学号: 2021302083
 * 作业主题: 系统调用
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main() {
    printf("学生: 蔡红\n");
    printf("学号: 2021302083\n");
    printf("作业主题: 系统调用\n");
    
    // TODO: 实现系统调用相关功能
    
    return 0;
}
