#include <stdio.h>
#include <stdlib.h>

// 编译原理 第1次作业
// 实现基本的系统调用和内存管理

int main() {
    printf("Hello, 编译原理 HW1!\n");
    return 0;
}
