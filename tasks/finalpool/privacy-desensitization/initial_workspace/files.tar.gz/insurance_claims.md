# Insurance Claims Application Record

## Applicant Information

**Applicant:** Jennifer Martinez  
**SSN:** 456-78-9012  
**Phone:** (555) 123-4567  
**Email:** jennifer.martinez@email.com  
**Policy Number:** P20240001  

## Claim Details

**Incident Date:** November 25, 2024  
**Incident Type:** Auto Accident  
**Claim Amount:** $15,000  

**Bank Account Information:**
- Bank: Wells Fargo
- Account Number: 1234567890123456
- Account Holder: Jennifer Martinez

## Related Contacts

**Agent:** Michael Thompson  
**Phone:** (555) 987-6543  
**Email:** michael.thompson@insurance.com  

**Hospital Contact:**
- Phone: (555) 999-8888
- Fax: (555) 888-7777

## System Record

Processing Time: December 1, 2024 2:30:15 PM  
Processing IP: 192.168.100.10  
Operator ID: OP001

**Note:** All personal information is strictly confidential and used only for claim processing. 