# 2024 Technology Conference Attendee List

## Conference Information
- **Conference Name:** National Innovation Summit
- **Date:** December 15, 2024
- **Location:** San Francisco Convention Center
- **Organizer Contact:** /hidden/

## Attendee List

### VIP Guests

**Dr. Johnson**

- Organization: Stanford University Computer Science
- Phone: /hidden/
- Email: /hidden/
- SSN: /hidden/

**Ms. Garcia, CTO**
- Company: Google Inc.
- Phone: /hidden/
- Email: /hidden/
- SSN: /hidden/

### Regular Attendees

| Name | Company | Phone | Email | SSN |
|------|---------|-------|-------|-----|
| Michael Brown | Microsoft | /hidden/ | /hidden/ | /hidden/ |
| Sarah Wilson | Apple Inc. | /hidden/ | /hidden/ | /hidden/ |
| David Martinez | Amazon | /hidden/ | /hidden/ | /hidden/ |

## Technical Support

**Conference System Admin:** Tech Support (/hidden/)
**Network Support:** /hidden/
**Server Address:** /hidden/
**Backup Contact:** /hidden/

## Accommodation

Hotel Customer Service: /hidden/
Emergency Contact: Manager Johnson (/hidden/)

**Notice:** Please protect personal information and prevent disclosure. 