# Insurance Claims Application Record

## Applicant Information

**Applicant:** Jennifer Martinez  
**SSN:** /hidden/  
**Phone:** /hidden/  
**Email:** /hidden/  
**Policy Number:** P20240001  

## Claim Details

**Incident Date:** November 25, 2024  
**Incident Type:** Auto Accident  
**Claim Amount:** $15,000  

**Bank Account Information:**

- Bank: Wells Fargo
- Account Number: 1234567890123456
- Account Holder: Jennifer Martinez

## Related Contacts

**Agent:** Michael Thompson  
**Phone:** /hidden/  
**Email:** /hidden/  

**Hospital Contact:**

- Phone: /hidden/
- Fax: /hidden/

## System Record

Processing Time: December 1, 2024 2:30:15 PM  
Processing IP: /hidden/  
Operator ID: OP001

**Note:** All personal information is strictly confidential and used only for claim processing. 