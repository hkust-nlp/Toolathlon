# Hospital Appointment Records

## December 2024 Appointment Information

### Internal Medicine

**Appointment Date: December 10, 2024 Morning**
- **Patient:** Maria Rodriguez
- **SSN:** /hidden/
- **Phone:** /hidden/
- **Department:** Internal Medicine
- **Doctor:** Dr. Johnson
- **Medical Record #:** M20241001
- **Email:** /hidden/

**Appointment Date: December 10, 2024 Afternoon**

- **Patient:** David Wilson
- **SSN:** /hidden/
- **Phone:** /hidden/
- **Department:** Cardiology
- **Doctor:** Dr. Smith
- **Insurance Card:** 1234567890123456
- **Email:** /hidden/

### Surgery Department

**Appointment Time: December 11, 2024 Morning**

- **Patient Name:** Robert Martinez
- **SSN:** /hidden/
- **Phone:** /hidden/
- **Department:** Orthopedics
- **Surgeon:** Dr. Brown
- **Registration Fee Payment:** Credit Card /hidden/

## Emergency Contacts

**Hospital Main:** /hidden/
**Emergency:** /hidden/
**Nursing Station:** /hidden/
**Appointment System:** /hidden/
**Backup Server:** /hidden/

## Important Notes

Please arrive 30 minutes early with ID and insurance card.