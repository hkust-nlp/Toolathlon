pip install -e .
# pip install --force-reinstall wandb